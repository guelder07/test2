from django.shortcuts import render
from django.conf import settings
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseForbidden
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import User
from flask import Flask, request, abort
from linebot import LineBotApi, WebhookParser
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError, LineBotApiError
from linebot.models import *
from app.models import *
from user.models import *
from app.Flex_Msg import *
import re
import requests
from opencc import OpenCC

import datetime
from datetime import datetime

from linebot.models import (
    MessageEvent, FollowEvent, PostbackEvent,
    TextMessage,
    PostbackAction,
    TextSendMessage, TemplateSendMessage,
    ButtonsTemplate
    )

from liffpy import (
    LineFrontendFramework as LIFF,
    ErrorResponse
)

liff_api = LIFF(settings.LINE_CHANNEL_ACCESS_TOKEN)
line_bot_api = LineBotApi(settings.LINE_CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(settings.LINE_CHANNEL_SECRET)


@handler.add(FollowEvent)   # 用戶關注
def handle_follow(event):

    uid = event.source.user_id
    profile = line_bot_api.get_profile(uid)
    name = profile.display_name
    pic_url = profile.picture_url
    if User_Info.objects.filter(uid=uid).exists() == False:
        User_Info.objects.create(uid=uid, name=name, pic_url=pic_url)
    line_bot_api.reply_message(
        event.reply_token,
        TextSendMessage(
            'Hello ' + name + '已加入會員囉')
    )


@csrf_exempt
def callback(request):
    if request.method == "POST":
        # get X-Line-Signature header value
        signature = request.META['HTTP_X_LINE_SIGNATURE']
        global domain
        domain = request.META['HTTP_HOST']

        # get request body as text
        body = request.body.decode('utf-8')

        # handle webhook body
        try:
            handler.handle(body, signature)
        except InvalidSignatureError:
            return HttpResponseBadRequest()


        return HttpResponse()
    else:
        return HttpResponseBadRequest()




@handler.add(MessageEvent, message=TextMessage)  # 用戶訊息
def handle_message(event):
    mtext = event.message.text
    message = []
    uid = event.source.user_id
    profile = line_bot_api.get_profile(uid)
    name = profile.display_name

    if re.search("@", mtext):   # 呼叫material選單
        result_message_array = []
        replyJsonPath = "material/" + event.message.text + "/reply.json"
        result_message_array = detect_json_array_to_new_message_array(replyJsonPath)
        line_bot_api.reply_message(event.reply_token, result_message_array)

    elif re.search("個人資料", mtext):     # User個人資料
         message.append(flex_message_example_1(uid))
         line_bot_api.reply_message(event.reply_token, message)

    elif re.search("eat", mtext):     # 暫時手動輸入食物品項
        job = mtext.split('/')
        datas = Food.objects.filter(en_name=job[1]) # 搜尋Food資料庫記錄，存成 datas

        for data in datas:   # 依序把資料存成字串
            tc_food_name = data.tc_name
            en_food_name = data.en_name
            cal = data.cal
            carb = data.carb
            pr = data.pr
            fat = data.fat
            User_eat.objects.create(uid=uid, name=name, tc_name=tc_food_name, en_name=en_food_name,
                                    cal=cal, pr=pr, fat=fat, carb=carb) # 新增資料於 User_eat資料庫
            message.append(TextSendMessage(text='你今天吃了' + tc_food_name +
                                                '  熱量'+str(cal)+
                                                '  蛋白質'+str(pr)+
                                                '  脂肪'+str(fat)+
                                                '  醣類'+str(carb)))
            #message.append(TextSendMessage(text='建立工作內容完成'))
            line_bot_api.reply_message(event.reply_token, message)



    elif re.search("查詢", mtext):   # 查詢個人營養值
        date = datetime.today().date()
        user = User_eat.objects.filter(uid=uid)  # 查詢 自己的id
        times = user.filter(created_date__date=date)  # 使用自己的id  搜尋時間
        cal, pr, fat, carb = 0, 0, 0, 0
        for time in times:  # 依序把資料存成字串
            cal = cal + time.cal
            pr = pr + time.pr
            fat = fat + time.fat
            carb = carb + time.carb

        message.append(TextSendMessage(text='今天一日所需各種營養素如下，請均衝飲食喔：'))
        message.append(flex(uid))
        message.append(TextSendMessage(text=str(date) + ' 營養總計如下：'))
        message.append(TextSendMessage(text="熱量" + str(round(cal, 2)) +
                                            '  脂質' + str(round(fat, 2)) +
                                            '  醣類' + str(round(carb, 2)) +
                                            '  蛋白質' + str(round(pr, 2)) ))
        line_bot_api.reply_message(event.reply_token, message)


    # elif re.search("ID", mtext):  # 查詢User_Info
    #
    #     users = User_Info.objects.filter(name=name)
    #     content = ''  # 回覆使用者的內容
    #     for user in users:
    #         content += user.name + '\n' + user.uid + '\n' + user.pic_url
    #     line_bot_api.reply_message(  # 回覆訊息
    #         event.reply_token,
    #         TextSendMessage(text=content)
    #     )


    elif re.search("https://", mtext):  # 自動將https網址轉成 liff
        try:
            # 新增LIFF頁面到LINEBOT中
            liff_id = liff_api.add(
                view_type="tall",
                view_url=mtext)

            message.append(TextSendMessage(text='https://liff.line.me/' + liff_id))
            line_bot_api.reply_message(event.reply_token, message)
        except:
            print(err.message)
    elif re.search("查詢liff", mtext):  # 查詢 liff
        print (liff_api.get())


    elif (event.message.text.find('@') != 1):
        myuid = "Line"
        mymsg = event.message.text
        r1 = requests.get("http://api.brainshop.ai/get?bid=154159&key=8AUfCxCOwuyKOaCT",
                          headers={
                              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:82.0) Gecko/20100101 Firefox/82.0"
                          },
                          params={
                              "uid": 154159,
                              "msg": mymsg
                          }
                          )
        r2 = json.loads(r1.text)
        cc = OpenCC("s2tw")
        # print(cc.convert(r2['cnt']))
        line_bot_api.reply_message(event.reply_token, TextSendMessage(text=cc.convert(r2['cnt'])))







# 引用會用到的套件
from linebot.models import (
    ImagemapSendMessage, TextSendMessage, ImageSendMessage, LocationSendMessage, FlexSendMessage, VideoSendMessage , StickerSendMessage , AudioSendMessage
)

import json
from linebot.models.template import (
    ButtonsTemplate, CarouselTemplate, ConfirmTemplate, ImageCarouselTemplate
)

from linebot.models.template import *
def detect_json_array_to_new_message_array(fileName):
    # 開啟檔案，轉成json
    with open(fileName,encoding='utf8') as f:
        jsonArray = json.load(f)

    # 解析json
    returnArray = []
    for jsonObject in jsonArray:

        # 讀取其用來判斷的元件
        message_type = jsonObject.get('type')

        # 轉換
        if message_type == 'text':
            returnArray.append(TextSendMessage.new_from_json_dict(jsonObject))
        elif message_type == 'imagemap':
            returnArray.append(ImagemapSendMessage.new_from_json_dict(jsonObject))
        elif message_type == 'template':
            returnArray.append(TemplateSendMessage.new_from_json_dict(jsonObject))
        elif message_type == 'image':
            returnArray.append(ImageSendMessage.new_from_json_dict(jsonObject))
        elif message_type == 'sticker':
            returnArray.append(StickerSendMessage.new_from_json_dict(jsonObject))
        elif message_type == 'audio':
            returnArray.append(AudioSendMessage.new_from_json_dict(jsonObject))
        elif message_type == 'location':
            returnArray.append(LocationSendMessage.new_from_json_dict(jsonObject))
        elif message_type == 'flex':
            returnArray.append(FlexSendMessage.new_from_json_dict(jsonObject))
        elif message_type == 'video':
            returnArray.append(VideoSendMessage.new_from_json_dict(jsonObject))

            # 回傳
    return returnArray


# ============ QuickReplay =================
'''
當收到PostbackEvent時
告知handler
'''
from linebot.models import PostbackEvent
from linebot.models import (
    QuickReply,
    QuickReplyButton,
    MessageAction
)
@handler.add (PostbackEvent)
def handel_postback_event(event):
    postback_data = event.postback.data
    '''
    製作QuickReply
    先做按鍵
    再作QuickReply
    夾帶SendMessae內，送回給用戶
    '''

    # qrb1 = QuickReplyButton(action=MessageAction(label='資料正確', text='正確'))
    # qrb2 = QuickReplyButton(action=MessageAction(label='想在重拍', text='重拍'))
    # qrb3 = QuickReplyButton(action=LocationAction(label="傳送位置"))
    # qrb4 = QuickReplyButton(action=CameraAction(label="拍照"))
    # qrb5 = QuickReplyButton(action=CameraRollAction(label="相簿"))
    # qrb6 = QuickReplyButton(action=DatetimePickerAction(label="時間選擇",data="時間選擇",mode='datetime'))

    qrb1 = QuickReplyButton(action=MessageAction(label='Yes',text='eat/'+postback_data)) # 寫入資料庫
    qrb2 = QuickReplyButton(action=MessageAction(label='No', text='已取消'))

    quick_reply_list = QuickReply([qrb1, qrb2])


    if postback_data == 'apple':
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage('新增資料',quick_reply=quick_reply_list)
        )

    elif postback_data == 'tianbula':
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage('新增資料',quick_reply=quick_reply_list)
        )


























